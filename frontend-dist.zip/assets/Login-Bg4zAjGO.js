import{r as x,j as e,G as ge,z as ve,P as ye,B as be,T as we,u as Se,C as Ne,D as je,m as c,L as Te}from"./index-B9HIDfL7.js";import{S as Ce}from"./SEO-BnB-d94V.js";import{P as Me}from"./PasswordInput-DGVR79Y_.js";import{S as Pe}from"./StarField-DooAhBk-.js";const se=["bg-amber","bg-coral","bg-grape","bg-mint"];function Ae(){const m=x.useMemo(()=>Array.from({length:22},(a,i)=>({id:i,left:Math.random()*100,size:2+Math.random()*3,duration:10+Math.random()*12,delay:Math.random()*12,color:se[Math.floor(Math.random()*se.length)]})),[]);return e.jsxs("div",{className:"pointer-events-none absolute inset-0 overflow-hidden",children:[e.jsx("div",{className:"animate-drift absolute inset-0 opacity-[0.5] bg-[radial-gradient(rgba(255,255,255,0.08)_1px,transparent_1px)] bg-[length:26px_26px]"}),e.jsx(ge,{variant:"blue"}),e.jsx(Pe,{count:70}),e.jsxs("div",{className:"absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2",children:[e.jsx("div",{className:"animate-spin-slow h-[560px] w-[560px] rounded-full border border-dashed border-amber/20"}),e.jsx("div",{className:"animate-spin-slow-reverse absolute inset-0 m-auto h-[400px] w-[400px] rounded-full border border-dashed border-grape/20"}),e.jsx("div",{className:"animate-spin-slow absolute inset-0 m-auto h-[260px] w-[260px] rounded-full border border-dashed border-coral/20"})]}),m.map(a=>e.jsx("span",{className:`animate-rise absolute bottom-0 rounded-full ${a.color} opacity-0`,style:{left:`${a.left}%`,width:a.size,height:a.size,animationDuration:`${a.duration}s`,animationDelay:`${a.delay}s`}},a.id)),e.jsx("div",{className:"absolute inset-0 bg-gradient-to-b from-ink via-transparent to-ink"})]})}const w=64,Be=`
attribute vec2 position;
attribute vec2 uv;
varying vec2 vUv;

void main() {
  vUv = uv;
  gl_Position = vec4(position, 0.0, 1.0);
}
`,Fe=`
precision highp float;

#define MAX_POINTS 64

uniform vec2 uResolution;
uniform vec2 uPoints[MAX_POINTS];
uniform float uPointCount;
uniform vec3 uColor;
uniform vec3 uSecondaryColor;
uniform float uTrailWidth;
uniform float uTaper;
uniform float uGlowIntensity;
uniform float uGlowSpread;
uniform float uHotspot;
uniform float uBrightness;
uniform float uOpacity;
uniform float uPulseSpeed;
uniform float uNoiseStrength;
uniform float uNormalBlend;
uniform float uTime;
uniform float uFade;

varying vec2 vUv;

float sRGB(float x) {
  if (x <= 0.00031308) return 12.92 * x;
  return 1.055 * pow(x, 1.0 / 2.4) - 0.055;
}

float hash(vec2 p) {
  return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
}

float filmGrain(vec2 p, float time) {
  float frame = time * 18.0;
  float frameIndex = mod(floor(frame), 256.0);
  float nextFrameIndex = mod(frameIndex + 1.0, 256.0);
  float blend = fract(frame);
  blend = blend * blend * (3.0 - 2.0 * blend);
  vec2 pixel = floor(p);
  float current = hash(pixel + vec2(frameIndex * 17.0, frameIndex * 31.0));
  float next = hash(pixel + vec2(nextFrameIndex * 17.0, nextFrameIndex * 31.0));
  return mix(current, next, blend) * 2.0 - 1.0;
}

void main() {
  vec2 pixel = vUv * uResolution;
  float denominator = max(uPointCount - 1.0, 1.0);
  float strongest = 0.0;
  float strongestCore = 0.0;
  float colorWeight = 0.0;
  vec3 colorSum = vec3(0.0);

  for (int i = 0; i < MAX_POINTS - 1; i++) {
    float index = float(i);
    float active = 1.0 - step(uPointCount - 1.0, index);
    vec2 start = uPoints[i];
    vec2 end = uPoints[i + 1];
    vec2 toPixel = pixel - start;
    vec2 segment = end - start;
    float along = clamp(dot(toPixel, segment) / max(dot(segment, segment), 0.0001), 0.0, 1.0);
    float progress = clamp((index + along) / denominator, 0.0, 1.0);
    float life = pow(max(1.0 - progress, 0.0), mix(0.55, 1.25, uTaper));
    float width = uTrailWidth * mix(1.0, 0.25, pow(progress, mix(0.55, 1.6, uTaper)));
    float distanceToTrail = length(toPixel - segment * along);
    float falloff = max(width * (0.8 + uGlowSpread * 1.4), 0.5);
    float beam = min(1.0, (falloff * falloff) / (distanceToTrail * distanceToTrail + falloff * falloff));
    float core = exp(-pow(distanceToTrail / max(width, 0.5), 2.0) * 2.5);
    float pulseAmount = min(abs(uPulseSpeed), 1.0);
    float pulse = 1.0 + sin(uTime * uPulseSpeed * 3.0 - progress * 11.0) * 0.16 * pulseAmount;
    float intensity = (core + beam * uGlowIntensity * 0.55) * life * pulse * active;
    vec3 segmentColor = mix(uColor, uSecondaryColor, progress);

    strongest = max(strongest, intensity);
    strongestCore = max(strongestCore, core * life * active);
    colorSum += segmentColor * intensity;
    colorWeight += intensity;
  }

  float grain = filmGrain(pixel, uTime);
  float noiseAmount = (1.0 - exp(-uNoiseStrength * 2.2)) * 0.4;
  float alpha = clamp(strongest * uOpacity * uFade, 0.0, 1.0);
  if (alpha < 0.0005) discard;

  vec3 color = colorSum / max(colorWeight, 0.0001);
  color = mix(color, vec3(1.0), smoothstep(0.25, 0.95, strongestCore) * uHotspot);
  float luminance = sRGB(clamp(strongest * uBrightness, 0.0, 1.0));
  luminance *= 1.0 + grain * noiseAmount;
  vec3 additiveColor = color * luminance;
  float normalAlpha = clamp(strongest * uBrightness * uOpacity * uFade, 0.0, 1.0);
  vec3 normalColor = mix(color, vec3(1.0), smoothstep(0.45, 1.0, strongestCore) * uHotspot * 0.35);
  gl_FragColor = vec4(mix(additiveColor, normalColor, uNormalBlend), mix(alpha, normalAlpha, uNormalBlend));
}
`,I=m=>{let a=(m||"").replace("#","").trim();a.length===3&&(a=a.split("").map(h=>h+h).join(""));const i=Number.parseInt(a||"000000",16);return[(i>>16&255)/255,(i>>8&255)/255,(i&255)/255]},f=(m,a,i)=>Math.min(Math.max(m,a),i),Ie=({color:m="#67E8F9",secondaryColor:a="#A78BFA",trailLength:i=40,trailWidth:h=8,trailTaper:R=.8,followSpeed:g=.16,glowIntensity:E=1.9,glowSpread:S=1.2,hotspot:N=.65,brightness:j=1.25,opacity:T=1,pulseSpeed:C=1.1,noiseStrength:k=.035,idleFade:y=!0,idleTimeout:b=700,fadeDuration:G=900,blendMode:U="screen",maxDevicePixelRatio:q=1.5,enabled:ue=!0,children:V,className:Y="",style:me,...de})=>{const J=x.useRef(null),K=x.useRef(null),L=x.useRef({});return L.current={color:m,secondaryColor:a,trailLength:i,trailWidth:h,trailTaper:R,followSpeed:g,glowIntensity:E,glowSpread:S,hotspot:N,brightness:j,opacity:T,pulseSpeed:C,noiseStrength:k,idleFade:y,idleTimeout:b,fadeDuration:G,maxDevicePixelRatio:q,blendMode:U,enabled:ue},x.useEffect(()=>{const s=J.current,Q=K.current;if(!s||!Q)return;const r=L.current,_=new ve({canvas:Q,alpha:!0,dpr:Math.min(window.devicePixelRatio||1,r.maxDevicePixelRatio)}),M=_.gl;M.clearColor(0,0,0,0);const O=Array(w*2).fill(0),l=Array.from({length:w},()=>({x:0,y:0})),v={x:0,y:0},p={x:0,y:0},o=new ye(M,{vertex:Be,fragment:Fe,uniforms:{uResolution:{value:[1,1]},uPoints:{value:O},uPointCount:{value:r.trailLength},uColor:{value:I(r.color)},uSecondaryColor:{value:I(r.secondaryColor)},uTrailWidth:{value:r.trailWidth},uTaper:{value:r.trailTaper},uGlowIntensity:{value:r.glowIntensity},uGlowSpread:{value:r.glowSpread},uHotspot:{value:r.hotspot},uBrightness:{value:r.brightness},uOpacity:{value:r.opacity},uPulseSpeed:{value:r.pulseSpeed},uNoiseStrength:{value:r.noiseStrength},uNormalBlend:{value:r.blendMode==="normal"?1:0},uTime:{value:0},uFade:{value:0}},transparent:!0,depthTest:!1,depthWrite:!1}),Z=new be(M,{geometry:new we(M),program:o});let W=1,z=1,P=!1,D=!1,A=0,H=performance.now(),ee=performance.now(),X=0,$=!1;const te=()=>{W=Math.max(s.clientWidth,1),z=Math.max(s.clientHeight,1),_.setSize(W,z),o.uniforms.uResolution.value=[W,z]},ce=(u,t)=>{v.x=u,v.y=t,p.x=u,p.y=t;for(const d of l)d.x=u,d.y=t;P=!0,A=1},B=u=>{const t=s.getBoundingClientRect(),d=f(u.clientX-t.left,0,t.width),F=f(t.height-(u.clientY-t.top),0,t.height);P||ce(d,F),v.x=d,v.y=F,D=!0,H=performance.now()},ae=()=>{D=!1,H=performance.now()},oe=u=>{if($)return;const t=L.current,d=Math.min((u-ee)/16.667,3);if(ee=u,P){const re=1-Math.pow(1-f(t.followSpeed,.01,.99),d),he=f(.28+t.followSpeed*.35,.08,.92),ie=1-Math.pow(1-he,d);p.x+=(v.x-p.x)*re,p.y+=(v.y-p.y)*re,l[0].x=p.x,l[0].y=p.y;for(let n=1;n<w;n++)l[n].x+=(l[n-1].x-l[n].x)*ie,l[n].y+=(l[n-1].y-l[n].y)*ie;for(let n=0;n<w;n++)O[n*2]=l[n].x,O[n*2+1]=l[n].y}const F=u-H,fe=t.idleFade&&(!D||F>t.idleTimeout),pe=16.667*d/Math.max(t.fadeDuration,16),xe=P&&t.enabled&&!fe?1:0;A+=(xe-A)*Math.min(1,pe*7),o.uniforms.uPointCount.value=f(Math.round(t.trailLength),2,w),o.uniforms.uColor.value=I(t.color),o.uniforms.uSecondaryColor.value=I(t.secondaryColor),o.uniforms.uTrailWidth.value=Math.max(t.trailWidth,.1),o.uniforms.uTaper.value=f(t.trailTaper,0,1),o.uniforms.uGlowIntensity.value=Math.max(t.glowIntensity,0),o.uniforms.uGlowSpread.value=Math.max(t.glowSpread,0),o.uniforms.uHotspot.value=f(t.hotspot,0,1),o.uniforms.uBrightness.value=Math.max(t.brightness,0),o.uniforms.uOpacity.value=f(t.opacity,0,1),o.uniforms.uPulseSpeed.value=t.pulseSpeed,o.uniforms.uNoiseStrength.value=f(t.noiseStrength,0,1),o.uniforms.uNormalBlend.value=t.blendMode==="normal"?1:0,o.uniforms.uTime.value=u*.001,o.uniforms.uFade.value=A,_.render({scene:Z}),$||(X=requestAnimationFrame(oe))},ne=new ResizeObserver(te);return ne.observe(s),s.addEventListener("pointermove",B),s.addEventListener("pointerenter",B),s.addEventListener("pointerleave",ae),te(),X=requestAnimationFrame(oe),()=>{$=!0,cancelAnimationFrame(X),ne.disconnect(),s.removeEventListener("pointermove",B),s.removeEventListener("pointerenter",B),s.removeEventListener("pointerleave",ae),Z.geometry.remove(),o.remove()}},[q]),e.jsxs("div",{ref:J,className:`glow-cursor${Y?` ${Y}`:""}`,style:me,...de,children:[e.jsx("canvas",{ref:K,className:"glow-cursor__canvas",style:{mixBlendMode:U},"aria-hidden":"true"}),V&&e.jsx("div",{className:"glow-cursor__content",children:V})]})},le={hidden:{opacity:0,y:12},show:{opacity:1,y:0}};function Le(){const{status:m,login:a,timedOut:i,clearTimedOut:h}=Se(),R=Ne(),[g,E]=x.useState({username:"",password:""}),[S,N]=x.useState(""),[j,T]=x.useState(!1);if(m==="authed")return e.jsx(je,{to:"/admin",replace:!0});function C(y){return b=>E(G=>({...G,[y]:b.target.value}))}async function k(y){y.preventDefault(),T(!0),N("");try{await a(g.username,g.password),h(),R("/admin",{replace:!0})}catch(b){N(b.message)}finally{T(!1)}}return e.jsxs(Ie,{color:"#2EC4B6",secondaryColor:"#8B5CF6",trailLength:40,trailWidth:8,trailTaper:.8,followSpeed:.16,glowIntensity:1.9,glowSpread:1.2,hotspot:.65,brightness:1.25,opacity:1,pulseSpeed:1.1,noiseStrength:.035,idleFade:!0,idleTimeout:700,fadeDuration:900,blendMode:"screen",className:"relative flex min-h-screen items-center justify-center overflow-hidden bg-ink px-4",children:[e.jsx(Ce,{path:"/login",title:"Sign in",noindex:!0}),e.jsx(Ae,{}),e.jsxs(c.div,{initial:{opacity:0,y:24,scale:.96},animate:{opacity:1,y:0,scale:1},transition:{type:"spring",stiffness:260,damping:22},className:"relative z-10 w-full max-w-sm",children:[e.jsx(c.div,{initial:{opacity:0},animate:{opacity:1},transition:{delay:.3},children:e.jsx(Te,{to:"/",className:"mb-4 inline-flex items-center gap-1.5 font-mono text-xs text-slate-300 transition-colors hover:text-paper",children:"← Back to site"})}),e.jsx("div",{className:"shadow-xl shadow-ink/10",children:e.jsxs("form",{onSubmit:k,className:"rounded-2xl border border-slate-200 bg-paper/85 p-8",children:[e.jsx(c.div,{initial:{scale:0,rotate:-20},animate:{scale:1,rotate:0},transition:{type:"spring",stiffness:300,damping:15,delay:.15},className:"inline-flex h-10 w-10 items-center justify-center rounded-xl bg-amber/10 text-amber",children:e.jsxs("svg",{viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round",className:"h-5 w-5",children:[e.jsx("rect",{x:"4",y:"10",width:"16",height:"10",rx:"2"}),e.jsx("path",{d:"M8 10V7a4 4 0 0 1 8 0v3"})]})}),e.jsx("h1",{className:"mt-3 font-display text-2xl font-semibold text-graphite",children:"Sign in"}),e.jsx("p",{className:"mt-1 font-mono text-xs text-slate",children:"Admin console access"}),i&&e.jsx(c.p,{initial:{opacity:0,height:0},animate:{opacity:1,height:"auto"},className:"mt-4 border border-amber/30 bg-amber/10 px-3 py-2.5 text-sm text-amber-dim",children:"You were signed out due to inactivity. Please sign in again."}),e.jsxs(c.div,{initial:"hidden",animate:"show",transition:{staggerChildren:.08,delayChildren:.35},className:"mt-6 space-y-4",children:[e.jsxs(c.label,{variants:le,transition:{duration:.35},className:"block",children:[e.jsx("span",{className:"mb-1.5 block text-sm font-medium text-graphite",children:"Username"}),e.jsx("input",{required:!0,type:"text",value:g.username,onChange:C("username"),className:"w-full border border-slate-200 bg-paper px-3 py-2.5 text-sm text-graphite outline-none transition-colors focus:border-amber"})]}),e.jsxs(c.label,{variants:le,transition:{duration:.35},className:"block",children:[e.jsx("span",{className:"mb-1.5 block text-sm font-medium text-graphite",children:"Password"}),e.jsx(Me,{required:!0,value:g.password,onChange:C("password")})]})]}),e.jsxs(c.button,{type:"submit",disabled:j,whileHover:{y:-2},whileTap:{scale:.97},transition:{type:"spring",stiffness:400,damping:20},className:"group relative isolate mt-6 w-full overflow-hidden rounded-lg bg-ink px-5 py-3 text-sm font-medium text-paper shadow-lg shadow-ink/20 disabled:opacity-60",children:[e.jsx("span",{className:"absolute inset-0 origin-left scale-x-0 bg-gradient-to-r from-amber to-coral transition-transform duration-300 ease-out group-hover:scale-x-100"}),e.jsx("span",{className:"relative",children:j?"Signing in…":"Sign in"})]}),S&&e.jsx(c.p,{initial:{opacity:0,y:-6},animate:{opacity:1,y:0},className:"mt-4 border-t border-slate-200 pt-4 text-sm text-red-700",children:S})]})})]})]})}export{Le as default};
